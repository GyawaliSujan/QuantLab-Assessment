import pandas as pd

def process_trades(input_file, output_file):
    try:
        # Load the data from the specified input file
        input_data = pd.read_csv(input_file, header=None, names=['TimeStamp', 'Symbol', 'Quantity', 'Price'])
    except Exception as e:
        print(f"Failed to read input file: {e}")
        return

    # Group the data by 'Symbol' to process metrics for each symbol
    grouped_data = input_data.groupby('Symbol')

    # Initialize a dictionary to store the computed results
    results = {
        'Symbol': [],
        'MaxTimeGap': [],
        'Volume': [],
        'WeightedAveragePrice': [],
        'MaxPrice': []
    }

    # Process each group to calculate required metrics
    for symbol, group in grouped_data:
        group_sorted = group.sort_values(by='TimeStamp')

        # Calculate maximum time gap between consecutive trades
        time_gaps = group_sorted['TimeStamp'].diff().fillna(0).astype(int)
        max_time_gap = time_gaps.max()

        # Calculate total volume traded
        total_volume = group_sorted['Quantity'].sum()

        # Calculate maximum trade price
        max_price = group_sorted['Price'].max()

        # Calculate weighted average price (truncated to whole number)
        weighted_total = (group_sorted['Quantity'] * group_sorted['Price']).sum()
        weighted_average_price = weighted_total // total_volume

        # Store the results
        results['Symbol'].append(symbol)
        results['MaxTimeGap'].append(max_time_gap)
        results['Volume'].append(total_volume)
        results['WeightedAveragePrice'].append(weighted_average_price)
        results['MaxPrice'].append(max_price)

    # Convert the results to a DataFrame and sort by 'Symbol'
    output_df = pd.DataFrame(results).sort_values(by='Symbol')

    try:
        # Save the DataFrame to the specified output file
        output_df.to_csv(output_file, index=False)
    except Exception as e:
        print(f"Failed to write output file: {e}")
        return

    print("Processing complete!")

# Call the function with your input and output file paths
process_trades('input.csv', 'output.csv')
